package com.sigcar.Classes;

public class Kilometragem {

    private String km;


    public String getKm() {
        return km;
    }

    public void setKm(String km) {
        this.km = km;
    }
}
